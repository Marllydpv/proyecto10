class Motocicleta:
    
    es_nueva = True
    
    motor = False

    def __init__(self, color, matricula, combustible_litros, numero_ruedas, marca, modelo, fecha_fabricacion,
                 velocidad_punta, peso):
      
        self.color = color
        self.matricula = matricula
        self.combustible_litros = combustible_litros
        self.numero_ruedas = numero_ruedas
        self.marca = marca
        self.modelo = modelo
        self.fecha_fabricacion = fecha_fabricacion
        self.velocidad_punta = velocidad_punta
        self.peso = peso

    def arrancar(self):
        if self.motor:
            print("El motor ya estaba en marcha.")
        else:
            self.motor = True
            print("El motor ha arrancado.")

    def detener(self):
        if self.motor:
            self.motor = False
            print("El motor ha sido detenido.")
        else:
            print("El motor ya estaba detenido.")

mi_motocicleta = Motocicleta(color="Rojo", matricula="123ABC", combustible_litros=5, numero_ruedas=2,
                            marca="Honda", modelo="CBR600", fecha_fabricacion="2023-01-15",
                            velocidad_punta=250, peso=180)

print(mi_motocicleta.es_nueva)  


mi_motocicleta.arrancar() 

mi_motocicleta.arrancar()  


mi_motocicleta.detener()  

mi_motocicleta.detener()  
